#!/usr/bin/env python3
"""Export data-analysis tool descriptions from a ``claude_tsa`` checkout.

The SFT pipeline does not execute tools through this module.  It uses the
exported bundle while constructing questions, then loads the real handlers
from ``pulsar.tsa.tools.ToolRegistry`` while generating trajectories.

The original project kept this helper next to the model metadata files.  This
implementation deliberately uses static source inspection: exporting a
catalog must not import or execute arbitrary tool modules.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Iterable, Sequence


@dataclass(frozen=True)
class ToolModule:
    """A tool expected by the time-series SFT task pool."""

    path: str
    category: str
    include_by_default: bool = True
    tool_name: str | None = None


_CATEGORY_TOOLS: dict[str, tuple[str, ...]] = {
    "data_io": (
        "data_scan",
        "data_profile",
        "data_quality_check",
        "data_convert",
        "list_channels",
        "channel_values",
        "register_artifact",
        "report_export",
    ),
    "statistics": (
        "channel_stats",
        "series_overview",
        "summary_stats",
        "shape_distri",
        "adf_test",
        "white_noise_test",
    ),
    "trend_and_seasonality": (
        "Trend_linear",
        "STL",
        "FFT",
        "compute_acf",
        "detect_periodicity",
        "seasonality_detector",
    ),
    "anomaly_and_quality": (
        "find_peaks",
        "outlier_clipper",
        "cpt_detector",
        "ts_imputation",
    ),
    "similarity_and_causality": (
        "pear_cross_correlation",
        "spear_cross_correlation",
        "dtw_distance",
        "causal",
    ),
    "features_and_forecasting": (
        "feature_generate",
        "tsfresh_extractor",
        "arima_forecast",
    ),
    "visualization": (
        "plot",
        "plot_univariate_distribution",
    ),
}


DATA_ANALYSIS_MODULES: tuple[ToolModule, ...] = tuple(
    ToolModule(
        path=f"pulsar/tsa/tools/{tool_name}.py",
        category=category,
        tool_name=tool_name,
    )
    for category, tool_names in _CATEGORY_TOOLS.items()
    for tool_name in tool_names
)


_DECLARATION_PATTERNS = (
    r"""(?:tool_name|name)\s*=\s*["']{name}["']""",
    r"""["'](?:tool_name|name)["']\s*:\s*["']{name}["']""",
    r"""mcp__tsa__{name}(?![A-Za-z0-9_])""",
    r"""(?:async\s+)?def\s+{name}\s*\(""",
    r"""(?:async\s+)?def\s+(?:handle_|run_){name}\s*\(""",
)


def select_modules(
    *,
    include_training: bool = False,
    include_knowledge: bool = False,
    all_tsa_tools: bool = False,
) -> list[ToolModule]:
    """Return tool selections compatible with the historical exporter API.

    The current SFT task pool contains data-analysis tools only.  The training
    and knowledge switches are accepted for API compatibility; selecting
    ``all_tsa_tools`` makes :func:`build_bundle` include additional explicit
    tool declarations discovered in the source tree.
    """

    del include_training, include_knowledge
    selected = list(DATA_ANALYSIS_MODULES)
    if all_tsa_tools:
        selected.append(
            ToolModule(
                path="pulsar/tsa/tools/**/*.py",
                category="tsa_tool",
                include_by_default=False,
                tool_name=None,
            )
        )
    return selected


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _tool_files(repo_root: Path) -> list[Path]:
    root = repo_root / "pulsar" / "tsa" / "tools"
    if not root.is_dir():
        raise FileNotFoundError(
            f"Invalid claude_tsa repository: expected tool sources under {root}"
        )
    return sorted(
        path
        for path in root.rglob("*.py")
        if path.name != "__pycache__" and "__pycache__" not in path.parts
    )


def _explicit_names(source: str) -> set[str]:
    names: set[str] = set()
    patterns = (
        r"""(?:tool_name|name)\s*=\s*["']([A-Za-z_][A-Za-z0-9_]*)["']""",
        r"""["'](?:tool_name|name)["']\s*:\s*["']([A-Za-z_][A-Za-z0-9_]*)["']""",
        r"""mcp__tsa__([A-Za-z_][A-Za-z0-9_]*)""",
    )
    for pattern in patterns:
        names.update(re.findall(pattern, source))
    return names


def _declares(source: str, tool_name: str) -> bool:
    escaped = re.escape(tool_name)
    return any(
        re.search(pattern.format(name=escaped), source)
        for pattern in _DECLARATION_PATTERNS
    )


def _description(source: str, tool_name: str) -> str:
    escaped = re.escape(tool_name)
    declaration = re.search(
        rf"""(?s)(?:tool_name|name)\s*=\s*["']{escaped}["'].{{0,1600}}?description\s*=\s*(["'])(.*?)\1""",
        source,
    )
    if declaration:
        return " ".join(declaration.group(2).split())
    mapping = re.search(
        rf"""(?s)["'](?:tool_name|name)["']\s*:\s*["']{escaped}["'].{{0,1600}}?["']description["']\s*:\s*(["'])(.*?)\1""",
        source,
    )
    if mapping:
        return " ".join(mapping.group(2).split())
    function = re.search(
        rf"""(?s)(?:async\s+)?def\s+(?:handle_|run_)?{escaped}\s*\([^)]*\)\s*(?:->[^:]+)?\s*:\s*(["']{{3}})(.*?)\1""",
        source,
    )
    if function:
        return " ".join(function.group(2).split())
    return f"Time-series data-analysis tool: {tool_name}"


def _schema_name(source: str, tool_name: str) -> str | None:
    escaped = re.escape(tool_name)
    declarations = (
        rf"""(?s)(?:tool_name|name)\s*=\s*["']{escaped}["'](.{{0,2000}})""",
        rf"""(?s)["'](?:tool_name|name)["']\s*:\s*["']{escaped}["'](.{{0,2000}})""",
    )
    for declaration in declarations:
        nearby = re.search(declaration, source)
        if not nearby:
            continue
        schema = re.search(
            r"""["']?(?:input_schema|schema)["']?\s*[:=]\s*([A-Za-z_][A-Za-z0-9_]*)""",
            nearby.group(1),
        )
        if schema:
            return schema.group(1)
    return None


def _category_for(tool_name: str, modules: Sequence[ToolModule]) -> str:
    for module in modules:
        if module.tool_name == tool_name:
            return module.category
    return "tsa_tool"


def _prebuilt_bundle(repo_root: Path) -> dict[str, Any] | None:
    candidates = (
        repo_root / "tool_dataset_sources" / "data_analysis_tools_bundle.json",
        repo_root / "agent_tools" / "data_analysis_tools_bundle.json",
        repo_root / "data_analysis_tools_bundle.json",
    )
    for path in candidates:
        if not path.is_file():
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("tools"), list) and data["tools"]:
            return data
    return None


def build_bundle(
    repo_root: Path,
    modules: Iterable[ToolModule] | None = None,
) -> dict[str, Any]:
    """Build a deterministic JSON-serializable tool bundle.

    A checked-in bundle inside the external repository is reused when
    available.  Otherwise, known task-pool tools are located through static
    source inspection.  No external source module is imported or executed.
    """

    repo_root = Path(repo_root).expanduser().resolve()
    selected = list(modules or DATA_ANALYSIS_MODULES)

    prebuilt = _prebuilt_bundle(repo_root)
    if prebuilt is not None:
        return prebuilt

    files = _tool_files(repo_root)
    sources = {
        path: path.read_text(encoding="utf-8", errors="replace")
        for path in files
    }
    requested_names = {
        module.tool_name
        for module in selected
        if module.tool_name and module.include_by_default
    }
    discover_all = any(module.tool_name is None for module in selected)
    if discover_all:
        for source in sources.values():
            requested_names.update(_explicit_names(source))

    records: list[dict[str, Any]] = []
    missing: list[str] = []
    for tool_name in sorted(requested_names):
        matches = [
            path
            for path, source in sources.items()
            if _declares(source, tool_name)
        ]
        if not matches:
            stem_matches = [
                path
                for path in files
                if path.stem.casefold() == tool_name.casefold()
            ]
            matches = stem_matches
        if not matches:
            missing.append(tool_name)
            continue
        source_path = matches[0]
        source = sources[source_path]
        relative = source_path.relative_to(repo_root).as_posix()
        records.append(
            {
                "tool_name": tool_name,
                "permission_name": f"mcp__tsa__{tool_name}",
                "category": _category_for(tool_name, selected),
                "description": _description(source, tool_name),
                "schema_name": _schema_name(source, tool_name),
                "source_file": relative,
                "implementation_source": source,
                "implementation_sha256": _sha256_text(source),
            }
        )

    if not records:
        raise ValueError(
            f"No tool declarations were found under {repo_root / 'pulsar' / 'tsa' / 'tools'}"
        )

    return {
        "metadata": {
            "format_version": "data_analysis_tools_bundle_v1",
            "mcp_server_name": "tsa",
            "source_root": str(repo_root),
            "export_method": "static_source_inspection",
            "requested_tool_count": len(requested_names),
            "exported_tool_count": len(records),
            "missing_tools": missing,
        },
        "tools": records,
    }


def write_bundle(bundle: dict[str, Any], output: Path, output_format: str = "json") -> None:
    """Write a bundle as JSON or JSONL using the historical function shape."""

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    normalized_format = output_format.lower().lstrip(".")
    if normalized_format == "json":
        output.write_text(
            json.dumps(bundle, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return
    if normalized_format == "jsonl":
        rows = [
            {"record_type": "metadata", **dict(bundle.get("metadata") or {})},
            *[
                {"record_type": "tool", **tool}
                for tool in bundle.get("tools", [])
            ],
        ]
        output.write_text(
            "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
            encoding="utf-8",
        )
        return
    raise ValueError(f"Unsupported output format: {output_format}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Freeze claude_tsa data-analysis tool descriptions"
    )
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--format", choices=("json", "jsonl"), default="json")
    parser.add_argument("--all-tsa-tools", action="store_true")
    args = parser.parse_args()

    bundle = build_bundle(
        args.repo_root,
        select_modules(all_tsa_tools=args.all_tsa_tools),
    )
    write_bundle(bundle, args.output, args.format)
    print(
        json.dumps(
            {
                "output": str(args.output),
                "tool_count": len(bundle.get("tools", [])),
                "missing_tools": (bundle.get("metadata") or {}).get("missing_tools", []),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
