# agent_tools

This directory contains catalog-export helpers, not executable TSA tools.

`export_data_analysis_tools.py` statically reads an external `claude_tsa`
checkout and freezes tool names, descriptions, source locations, source
hashes, and implementation text into `data_analysis_tools_bundle.json`.
Static inspection is intentional: preparing a catalog must not execute tool
modules.

The main SFT pipeline imports these compatibility functions:

- `select_modules(...)`
- `build_bundle(repo_root, modules)`
- `write_bundle(bundle, output_path, format)`

Example:

```powershell
python agent_tools/export_data_analysis_tools.py `
  --repo-root C:/path/to/claude_tsa `
  --output tool_dataset_sources/data_analysis_tools_bundle.json
```

The executable handlers are still loaded from
`pulsar.tsa.tools.ToolRegistry` in the external repository.

The configuration also refers to `metadata_1.json`, `metadata_2.json`, and
`metadata_3.json`. Those files describe the real model packages available to
the TSA runtime. They are source data, not generated defaults, and should be
copied from the tool/model repository or replaced with equivalent truthful
metadata paths.

