"""Utilities for freezing external TSA tool metadata.

The executable tools live in the external ``claude_tsa`` repository.  This
package only exports a reproducible description bundle for the SFT pipeline.
"""

